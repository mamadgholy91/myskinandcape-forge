package com.example.myskinandcape;

import com.example.myskinandcape.net.SkinBroadcastPayload;
import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;

public final class MySkinAndCapeClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        KeyMapping.Category category = KeyMapping.Category.register(
                Identifier.fromNamespaceAndPath(MySkinAndCape.MOD_ID, "main"));
        KeyMapping open = KeyBindingHelper.registerKeyBinding(
                new KeyMapping("key.myskinandcape.open", InputConstants.KEY_O, category));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (open.consumeClick()) client.setScreen(new WardrobeScreen());
        });

        ClientPlayNetworking.registerGlobalReceiver(SkinBroadcastPayload.TYPE, (payload, context) ->
                SkinManager.setRemote(payload.uuid(), payload.png(), payload.slim()));

        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            SkinManager.reload();
            SkinManager.sendOwn();
        });
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> SkinManager.clearRemote());
    }
}
