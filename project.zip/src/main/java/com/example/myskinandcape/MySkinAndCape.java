package com.example.myskinandcape;

import com.example.myskinandcape.net.SetSkinPayload;
import com.example.myskinandcape.net.SkinBroadcastPayload;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

/** Common/server side: relays skins between players who have the mod. */
public final class MySkinAndCape implements ModInitializer {
    public static final String MOD_ID = "myskinandcape";
    public static final int MAX_SKIN_BYTES = 24 * 1024;

    private record Stored(byte[] png, boolean slim) {}

    private static final Map<UUID, Stored> SKINS = new ConcurrentHashMap<>();

    @Override
    public void onInitialize() {
        PayloadTypeRegistry.playC2S().register(SetSkinPayload.TYPE, SetSkinPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(SkinBroadcastPayload.TYPE, SkinBroadcastPayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(SetSkinPayload.TYPE, (payload, context) -> {
            byte[] png = payload.png();
            if (png.length != 0 && !looksLikePng(png)) return;
            ServerPlayer sender = context.player();
            UUID id = sender.getUUID();
            if (png.length == 0) SKINS.remove(id);
            else SKINS.put(id, new Stored(png, payload.slim()));
            broadcast(context.server(), sender, new SkinBroadcastPayload(id, png, payload.slim()));
        });

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayer joining = handler.getPlayer();
            if (!ServerPlayNetworking.canSend(joining, SkinBroadcastPayload.TYPE)) return;
            for (Map.Entry<UUID, Stored> e : SKINS.entrySet()) {
                ServerPlayNetworking.send(joining,
                        new SkinBroadcastPayload(e.getKey(), e.getValue().png(), e.getValue().slim()));
            }
        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            ServerPlayer leaving = handler.getPlayer();
            if (SKINS.remove(leaving.getUUID()) != null) {
                broadcast(server, leaving, new SkinBroadcastPayload(leaving.getUUID(), new byte[0], false));
            }
        });
    }

    private static void broadcast(MinecraftServer server, ServerPlayer except, SkinBroadcastPayload payload) {
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            if (p == except) continue;
            if (ServerPlayNetworking.canSend(p, SkinBroadcastPayload.TYPE)) {
                ServerPlayNetworking.send(p, payload);
            }
        }
    }

    private static boolean looksLikePng(byte[] b) {
        return b.length > 8 && (b[0] & 0xFF) == 0x89 && b[1] == 'P' && b[2] == 'N' && b[3] == 'G';
    }
}
