package com.example.myskinandcape.net;

import com.example.myskinandcape.MySkinAndCape;
import java.util.UUID;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Server -> client: skin of player {uuid} (empty png = remove). */
public record SkinBroadcastPayload(UUID uuid, byte[] png, boolean slim) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<SkinBroadcastPayload> TYPE =
            new CustomPacketPayload.Type<>(Identifier.fromNamespaceAndPath(MySkinAndCape.MOD_ID, "skin_broadcast"));

    public static final StreamCodec<FriendlyByteBuf, SkinBroadcastPayload> CODEC =
            CustomPacketPayload.codec(SkinBroadcastPayload::write, SkinBroadcastPayload::new);

    public SkinBroadcastPayload(FriendlyByteBuf buf) {
        this(buf.readUUID(), buf.readByteArray(MySkinAndCape.MAX_SKIN_BYTES), buf.readBoolean());
    }

    private void write(FriendlyByteBuf buf) {
        buf.writeUUID(uuid);
        buf.writeByteArray(png);
        buf.writeBoolean(slim);
    }

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
