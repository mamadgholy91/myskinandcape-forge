package com.example.myskinandcape.mixin;

import com.example.myskinandcape.SkinManager;
import java.util.UUID;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.resources.ClientAsset;
import net.minecraft.world.entity.player.PlayerModelType;
import net.minecraft.world.entity.player.PlayerSkin;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Every place that asks "what skin does this player have?" goes through PlayerInfo#getSkin. */
@Mixin(PlayerInfo.class)
public abstract class PlayerInfoMixin {
    @Inject(method = "getSkin", at = @At("RETURN"), cancellable = true)
    private void myskinandcape$override(CallbackInfoReturnable<PlayerSkin> cir) {
        UUID id = SkinManager.uuidOf(this);
        if (id == null) return;
        SkinManager.Skin s = SkinManager.lookup(id);
        if (s == null) return;
        PlayerSkin orig = cir.getReturnValue();
        cir.setReturnValue(new PlayerSkin(
                new ClientAsset.ResourceTexture(s.tex(), s.tex()),
                orig.cape(), orig.elytra(),
                s.slim() ? PlayerModelType.SLIM : PlayerModelType.WIDE,
                orig.secure()));
    }
}
