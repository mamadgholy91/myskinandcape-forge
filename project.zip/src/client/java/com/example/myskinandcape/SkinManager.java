package com.example.myskinandcape;

import com.example.myskinandcape.net.SetSkinPayload;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.blaze3d.platform.NativeImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Stream;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.resources.Identifier;

/** All client-side skin state: local files, textures, remote players' skins, config. */
public final class SkinManager {
    public record Entry(String name, byte[] png, boolean slim, Identifier tex) {}
    public record Skin(Identifier tex, boolean slim) {}
    private record Prepared(byte[] png, boolean slim) {}

    private static final Path DIR = FabricLoader.getInstance().getConfigDir().resolve("myskinandcape");
    public static final Path SKIN_DIR = DIR.resolve("skins");
    private static final Path CONFIG = DIR.resolve("settings.json");

    private static final List<Entry> ENTRIES = new ArrayList<>();
    private static final Map<UUID, Skin> REMOTE = new HashMap<>();
    private static String selectedName = "";
    private static boolean applied = false;
    private static boolean configLoaded = false;
    private static int counter = 0;
    public static int skipped = 0;

    private SkinManager() {}

    // ---------- config ----------
    private static void loadConfig() {
        if (configLoaded) return;
        configLoaded = true;
        try {
            if (Files.exists(CONFIG)) {
                JsonObject o = JsonParser.parseString(Files.readString(CONFIG)).getAsJsonObject();
                if (o.has("skin")) selectedName = o.get("skin").getAsString();
                if (o.has("applied")) applied = o.get("applied").getAsBoolean();
            }
        } catch (Exception ignored) {}
    }

    private static void saveConfig() {
        try {
            Files.createDirectories(DIR);
            JsonObject o = new JsonObject();
            o.addProperty("skin", selectedName);
            o.addProperty("applied", applied);
            Files.writeString(CONFIG, o.toString());
        } catch (IOException ignored) {}
    }

    // ---------- local skins ----------
    public static List<Entry> entries() { return ENTRIES; }

    public static int selectedIndex() {
        for (int i = 0; i < ENTRIES.size(); i++) if (ENTRIES.get(i).name().equals(selectedName)) return i;
        return -1;
    }

    public static Entry active() {
        if (!applied) return null;
        int i = selectedIndex();
        return i < 0 ? null : ENTRIES.get(i);
    }

    public static boolean isApplied() { return active() != null; }

    public static void reload() {
        loadConfig();
        TextureManager tm = Minecraft.getInstance().getTextureManager();
        for (Entry e : ENTRIES) tm.release(e.tex());
        ENTRIES.clear();
        skipped = 0;
        try { Files.createDirectories(SKIN_DIR); } catch (IOException ignored) {}
        List<Path> files;
        try (Stream<Path> s = Files.list(SKIN_DIR)) {
            files = s.filter(p -> p.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".png"))
                    .sorted().toList();
        } catch (IOException e) {
            return;
        }
        for (Path p : files) {
            String name = p.getFileName().toString();
            try {
                if (Files.size(p) > 1_000_000) { skipped++; continue; }
                Prepared prep = prepare(Files.readAllBytes(p), name);
                if (prep == null) { skipped++; continue; }
                Identifier id = register(prep.png(), "skin/local_" + (counter++));
                if (id == null) { skipped++; continue; }
                ENTRIES.add(new Entry(name, prep.png(), prep.slim(), id));
            } catch (IOException e) {
                skipped++;
            }
        }
    }

    /** Select a skin and turn it on/off, save, and tell the server. */
    public static void apply(int index, boolean on) {
        if (index >= 0 && index < ENTRIES.size()) selectedName = ENTRIES.get(index).name();
        applied = on && selectedIndex() >= 0;
        saveConfig();
        sendOwn();
    }

    public static void sendOwn() {
        if (!ClientPlayNetworking.canSend(SetSkinPayload.TYPE)) return;
        Entry e = active();
        ClientPlayNetworking.send(e == null
                ? new SetSkinPayload(new byte[0], false)
                : new SetSkinPayload(e.png(), e.slim()));
    }

    // ---------- remote skins ----------
    public static void setRemote(UUID id, byte[] png, boolean slim) {
        TextureManager tm = Minecraft.getInstance().getTextureManager();
        Skin old = REMOTE.remove(id);
        if (old != null) tm.release(old.tex());
        if (png.length == 0) return;
        Prepared prep = prepare(png, "");
        if (prep == null) return;
        Identifier tex = register(prep.png(), "skin/remote_" + (counter++));
        if (tex != null) REMOTE.put(id, new Skin(tex, slim));
    }

    public static void clearRemote() {
        TextureManager tm = Minecraft.getInstance().getTextureManager();
        for (Skin s : REMOTE.values()) tm.release(s.tex());
        REMOTE.clear();
    }

    /** Skin override for a player, or null to keep the normal skin. */
    public static Skin lookup(UUID id) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && id.equals(mc.player.getUUID())) {
            Entry e = active();
            return e == null ? null : new Skin(e.tex(), e.slim());
        }
        return REMOTE.get(id);
    }

    // ---------- helpers ----------
    private static Prepared prepare(byte[] raw, String name) {
        try (NativeImage img = NativeImage.read(new ByteArrayInputStream(raw))) {
            if (img.getWidth() != 64 || img.getHeight() != 64) return null;
            byte[] png = img.asByteArray();
            if (png.length > MySkinAndCape.MAX_SKIN_BYTES) return null;
            String n = name.toLowerCase(Locale.ROOT);
            boolean slim;
            if (n.contains("slim")) slim = true;
            else if (n.contains("wide") || n.contains("steve")) slim = false;
            else slim = (img.getPixel(47, 20) >>> 24) == 0; // Alex-style arm has a transparent column
            return new Prepared(png, slim);
        } catch (Exception e) {
            return null;
        }
    }

    private static Identifier register(byte[] png, String path) {
        try {
            NativeImage img = NativeImage.read(new ByteArrayInputStream(png));
            Identifier id = Identifier.fromNamespaceAndPath(MySkinAndCape.MOD_ID, path);
            Minecraft.getInstance().getTextureManager().register(id, new DynamicTexture(id::toString, img));
            return id;
        } catch (Exception e) {
            return null;
        }
    }

    // PlayerInfo.getProfile().id() / getId() -- looked up reflectively to survive API renames.
    private static Method getProfile, idMethod;
    private static boolean reflectionFailed = false;

    public static UUID uuidOf(Object playerInfo) {
        if (reflectionFailed) return null;
        try {
            if (getProfile == null) getProfile = playerInfo.getClass().getMethod("getProfile");
            Object profile = getProfile.invoke(playerInfo);
            if (idMethod == null) {
                try { idMethod = profile.getClass().getMethod("id"); }
                catch (NoSuchMethodException e) { idMethod = profile.getClass().getMethod("getId"); }
            }
            return idMethod.invoke(profile) instanceof UUID u ? u : null;
        } catch (Exception e) {
            reflectionFailed = true;
            return null;
        }
    }
}
