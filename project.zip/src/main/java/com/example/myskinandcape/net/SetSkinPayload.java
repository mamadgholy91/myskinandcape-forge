package com.example.myskinandcape.net;

import com.example.myskinandcape.MySkinAndCape;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;

/** Client -> server: my skin (empty png = no custom skin). */
public record SetSkinPayload(byte[] png, boolean slim) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<SetSkinPayload> TYPE =
            new CustomPacketPayload.Type<>(Identifier.fromNamespaceAndPath(MySkinAndCape.MOD_ID, "set_skin"));

    public static final StreamCodec<FriendlyByteBuf, SetSkinPayload> CODEC =
            CustomPacketPayload.codec(SetSkinPayload::write, SetSkinPayload::new);

    public SetSkinPayload(FriendlyByteBuf buf) {
        this(buf.readByteArray(MySkinAndCape.MAX_SKIN_BYTES), buf.readBoolean());
    }

    private void write(FriendlyByteBuf buf) {
        buf.writeByteArray(png);
        buf.writeBoolean(slim);
    }

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
