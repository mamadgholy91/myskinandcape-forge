package com.example.myskinandcape;

import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;

public final class WardrobeScreen extends Screen {
    private int view;

    public WardrobeScreen() {
        super(Component.literal("My Skin & Cape v0.4"));
        SkinManager.reload();
        view = Math.max(0, SkinManager.selectedIndex());
    }

    private int top() { return Math.max(6, (height - 236) / 2); }

    @Override
    protected void init() {
        int cx = width / 2;
        int t = top();
        addRenderableWidget(Button.builder(Component.literal("<"), b -> step(-1))
                .bounds(cx - 105, t + 150, 40, 20).build());
        addRenderableWidget(Button.builder(Component.literal(">"), b -> step(1))
                .bounds(cx + 65, t + 150, 40, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Apply"), b -> {
            if (!SkinManager.entries().isEmpty()) SkinManager.apply(view, true);
        }).bounds(cx - 75, t + 176, 70, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Disable"), b ->
                SkinManager.apply(-1, false)).bounds(cx + 5, t + 176, 70, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Reload"), b -> {
            SkinManager.reload();
            view = Math.max(0, Math.min(view, SkinManager.entries().size() - 1));
        }).bounds(cx - 75, t + 202, 70, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
                .bounds(cx + 5, t + 202, 70, 20).build());
    }

    private void step(int d) {
        int n = SkinManager.entries().size();
        if (n > 0) view = (view + d + n) % n;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        super.render(g, mouseX, mouseY, delta);
        int cx = width / 2;
        int t = top();
        List<SkinManager.Entry> list = SkinManager.entries();

        g.drawCenteredString(font, title, cx, t, 0xFFFFFFFF);
        SkinManager.Entry active = SkinManager.active();
        g.drawCenteredString(font,
                Component.literal(active == null ? "Custom skin: OFF" : "Active: " + active.name()),
                cx, t + 14, 0xFFAAAAAA);

        if (list.isEmpty()) {
            g.drawCenteredString(font, Component.literal("No valid skins found."), cx, t + 50, 0xFFFFFFFF);
            g.drawCenteredString(font, Component.literal("Put 64x64 PNG files in:"), cx, t + 66, 0xFFAAAAAA);
            g.drawCenteredString(font, Component.literal(SkinManager.SKIN_DIR.toString()), cx, t + 80, 0xFFFFFF55);
            g.drawCenteredString(font, Component.literal("then press Reload."), cx, t + 94, 0xFFAAAAAA);
            return;
        }

        view = Math.max(0, Math.min(view, list.size() - 1));
        SkinManager.Entry e = list.get(view);

        // full texture sheet (left) and enlarged face + hat layer (right)
        g.blit(RenderPipelines.GUI_TEXTURED, e.tex(), cx - 105, t + 38, 0f, 0f, 96, 96, 64, 64, 64, 64);
        g.blit(RenderPipelines.GUI_TEXTURED, e.tex(), cx + 9, t + 38, 8f, 8f, 96, 96, 8, 8, 64, 64);
        g.blit(RenderPipelines.GUI_TEXTURED, e.tex(), cx + 9, t + 38, 40f, 8f, 96, 96, 8, 8, 64, 64);

        g.drawCenteredString(font,
                Component.literal(e.name() + (e.slim() ? " (slim)" : " (wide)")), cx, t + 152, 0xFFFFFFFF);
        g.drawCenteredString(font,
                Component.literal((view + 1) + " / " + list.size()), cx, t + 164, 0xFFAAAAAA);
    }
}
